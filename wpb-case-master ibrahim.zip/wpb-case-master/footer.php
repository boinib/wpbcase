<?php defined('ABSPATH') || exit('Forbidden');

get_template_part('partials/footer');

wp_footer();

?>

</body>

</html>