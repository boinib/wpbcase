<?php 
/* Template Name: Blog Page */
defined('ABSPATH') || exit('Forbidden');

get_header();

function render_section($section) {
    set_query_var('title', $section['title']);
    set_query_var('subtitle', $section['subtitle']);
    set_query_var('paragraph', $section['paragraph']);
    set_query_var('image_url', $section['image_url']);
    set_query_var('button_label', $section['button_label']);
    set_query_var('reverse', $section['reverse']);
    ?>
    <div class="container">
        <?php get_template_part('partials/component/text-image'); ?>
    </div>
    <?php
}

$sections = [
    [
        'title' => 'Een Dag in het Leven van Bas, een WordPress Developer bij WP Brothers',
        'subtitle' => '',
        'paragraph' => 'Bij WP Brothers is geen enkele dag hetzelfde, en dat maakt werken hier zo ontzettend leuk. Vandaag neem ik je mee in een typische werkdag van mij, Bas, een van de WordPress developers bij WP Brothers.',
        'image_url' => get_template_directory_uri() . '/assets/images/a11b35bea09068a555b885ee67a0275905f8e845.jpg',
        'button_label' => 'Over ons',
        'reverse' => false,
    ]
];

foreach ($sections as $section) {
    render_section($section);
}

function render_job_item($job) {
    set_query_var('job', $job);
    get_template_part('partials/component/job-item');
}

$job_items = [
    [
        'image_url' => get_template_directory_uri() . '/assets/images/f2457a37deb163394423f7e2a3e8cf462b9ca5e0.jpg',
        'title' => 'Een Dag in het Leven van een WP Brothers Developer: Verwacht het Onverwachte!',
        'tag' => 'Blog',
        'location' => 'Locatie',
        'employment_type' => 'Full-time'
    ],
    [
        'image_url' => get_template_directory_uri() . '/assets/images/f2457a37deb163394423f7e2a3e8cf462b9ca5e0.jpg',
        'title' => 'Waarom Werken bij WP Brothers Als WordPress Developer Jouw Beste Beslissing Ooit Zal Zijn',
        'tag' => 'Blog',
        'location' => 'Locatie',
        'employment_type' => 'Full-time'
    ],
    [
        'image_url' => get_template_directory_uri() . '/assets/images/f2457a37deb163394423f7e2a3e8cf462b9ca5e0.jpg',
        'title' => 'Van Plugin-Problemen tot Klantensuccessen: Mijn Avonturen bij WP Brothers',
        'tag' => 'Blog',
        'location' => 'Locatie',
        'employment_type' => 'Full-time'
    ],
];

?>

<div class="job-container">
    <?php foreach ($job_items as $job): ?>
        <?php render_job_item($job); ?>
    <?php endforeach; ?>
</div>

<?php get_footer(); ?>
