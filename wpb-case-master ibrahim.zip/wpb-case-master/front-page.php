<?php 
/* Template Name: Home Page */
defined('ABSPATH') || exit('Forbidden');

get_header();



function render_section($section) {
    set_query_var('title', $section['title']);
    set_query_var('subtitle', $section['subtitle']);
    set_query_var('paragraph', $section['paragraph']);
    set_query_var('image_url', $section['image_url']);
    set_query_var('button_label', $section['button_label']);
    set_query_var('reverse', $section['reverse']);
    ?>
    <div class="container">
        <?php get_template_part('partials/component/text-image'); ?>
    </div>
    <?php
}

$sections = [
    [
        'title' => 'Waarom WP Brothers',
        'subtitle' => 'Over ons',
        'paragraph' => 'Bij WP Brothers draait alles om creativiteit, innovatie en samenwerking. Wij zijn een dynamisch team van WordPress fanaten die de grenzen van webontwikkeling opzoeken en verleggen. Werken bij ons betekent deel uitmaken van een hechte familie die samenwerkt om de beste WordPress-oplossingen te bieden aan onze klanten.',
        'image_url' => get_template_directory_uri() . '/assets/images/2cbdc7b29b8b729db1b0ad933d96d3cbc1f83268.jpg',
        'button_label' => 'Over ons',
        'reverse' => false,
    ],
    [
        'title' => 'Sluit je aan bij WP Brothers',
        'subtitle' => 'Solliciteren',
        'paragraph' => 'Als je klaar bent om je carrière naar een hoger niveau te tillen en deel wilt uitmaken van een team dat streeft naar uitmuntendheid, dan is WP Brothers de plek voor jou. We zijn altijd op zoek naar getalenteerde WordPress developers die onze passie voor webontwikkeling delen. Kom en ontdek waarom werken bij WP Brothers niet zomaar een baan is, maar een avontuur vol kansen en groei.',
        'image_url' => get_template_directory_uri() . '/assets/images/2cbdc7b29b8b729db1b0ad933d96d3cbc1f83268.jpg',
        'button_label' => 'Werken bij',
        'reverse' => true,
    ]
];

foreach ($sections as $section) {
    render_section($section);
}

function render_job_item($job) {
    set_query_var('job', $job);
    get_template_part('partials/component/job-item');
}

$job_items = [
    [
        'image_url' => get_template_directory_uri() . '/assets/images/f2457a37deb163394423f7e2a3e8cf462b9ca5e0.jpg',
        'title' => 'Een Dag in het Leven van een WP Brothers Developer: Verwacht het Onverwachte!',
        'tag' => 'Blog',
        'location' => 'Locatie',
        'employment_type' => 'Full-time'
    ],
    [
        'image_url' => get_template_directory_uri() . '/assets/images/f2457a37deb163394423f7e2a3e8cf462b9ca5e0.jpg',
        'title' => 'Waarom Werken bij WP Brothers Als WordPress Developer Jouw Beste Beslissing Ooit Zal Zijn',
        'tag' => 'Blog',
        'location' => 'Locatie',
        'employment_type' => 'Full-time'
    ],
    [
        'image_url' => get_template_directory_uri() . '/assets/images/f2457a37deb163394423f7e2a3e8cf462b9ca5e0.jpg',
        'title' => 'Van Plugin-Problemen tot Klantensuccessen: Mijn Avonturen bij WP Brothers',
        'tag' => 'Blog',
        'location' => 'Locatie',
        'employment_type' => 'Full-time'
    ],
];

?>

<div class="job-container">
    <?php foreach ($job_items as $job): ?>
        <?php render_job_item($job); ?>
    <?php endforeach; ?>
</div>

<?php get_footer(); ?>
