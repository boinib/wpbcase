<?php defined('ABSPATH') || exit('Forbidden'); ?>

</main>

<footer>
  <div class="container">
    <div class="footer-content">
      <div class="footer-logo">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/footerlogo.png" alt="WP Brothers Logo" />
      <p>WP Brothers is een gespecialiseerd bureau op het gebied van het WordPress CMS en is onderdeel van Social Brothers.</p>
      </div>

      <div class="footer-menu">
        <h4>Menu</h4>
        <ul>
          <li><a href="#">Heading 1</a></li>
          <li><a href="#">Heading 2</a></li>
          <li><a href="#">Heading 3</a></li>
        </ul>
      </div>

      <div class="footer-contact">
        <h4>Contact</h4>
        <p><a href="tel:0307370902">030 737 09 02</a></p>
        <p><a href="mailto:info@wpbrothers.nl">info@wpbrothers.nl</a></p>
      </div>
    </div>
  </div>
</footer>
