<?php
$image_url = isset($job['image_url']) ? $job['image_url'] : 'default-image.jpg';
$title = isset($job['title']) ? $job['title'] : 'Een Dag in het Leven van een WP Brothers Developer: Verwacht het Onverwachte!';
$tags = isset($job['tag']) ? $job['tag'] : 'Blog';
$location_tag = isset($job['location']) ? $job['location'] : 'Locatie';
$employment_type = isset($job['employment_type']) ? $job['employment_type'] : 'Full-time';
?>

<div class="job-block">
    <div class="job-info">
        <img src="<?php echo esc_url($image_url); ?>" alt="Job image" />
        <div class="title-text">
            <?php echo htmlspecialchars($title); ?>
        </div>
        <div class="tag-container">
            <div class="tag">
                <div class="tag-text"><?php echo htmlspecialchars($tags); ?></div>
            </div>
            <div class="location-tag">
                <div class="tag-text"><?php echo htmlspecialchars($location_tag); ?></div>
            </div>
            <div class="employment-type">
                <div class="tag-text"><?php echo htmlspecialchars($employment_type); ?></div>
            </div>
        </div>
    </div>
</div>
