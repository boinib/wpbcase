<?php

$title = get_query_var('title');
$subtitle = get_query_var('subtitle');
$paragraph = get_query_var('paragraph');
$image_url = get_query_var('image_url');
$button_label = get_query_var('button_label');
$reverse = get_query_var('reverse');
?>

<div class="section-container">
    <div class="text-image">
        <?php if ($reverse): ?>
            <div class="image">
                <img src="<?php echo esc_url($image_url); ?>" alt="Checker" width="546" height="407" />
            </div>
            <div class="text-box">
                <div class="body">
                    <div class="header">
                        <p class="subtitle"><?php echo esc_html($subtitle); ?></p>
                        <h1 class="content-header"><?php echo esc_html($title); ?></h1>
                    </div>

                    <p class="content-paragraph"><?php echo esc_html($paragraph); ?></p>

                    <div class="button-section">
                        <div class="button-large">
                            <div class="base-button">
                                <button class="button-label"><?php echo esc_html($button_label); ?></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="text-box">
                <div class="body">
                    <div class="header">
                        <p class="subtitle"><?php echo esc_html($subtitle); ?></p>
                        <h1 class="content-header"><?php echo esc_html($title); ?></h1>
                    </div>

                    <p class="content-paragraph"><?php echo esc_html($paragraph); ?></p>

                    <div class="button-section">
                        <div class="button-large">
                            <div class="base-button">
                                <span class="button-label"><?php echo esc_html($button_label); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="image">
                <img src="<?php echo esc_url($image_url); ?>" alt="Checker" width="546" height="407" />
            </div>
        <?php endif; ?>
    </div>
</div>
