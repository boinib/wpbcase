<nav class="navbar">
  <div class="navbar-menu-mobile">
    <span></span>
    <span></span>
    <span></span>
  </div>

  <div class="navbar-logo">
    <a href="/">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" alt="WP Brothers Logo" />
    </a>
  </div>

  <div class="navbar-menu">
    <a href="http://wpb-case.local/blogdetail" class="navbar-menu-item">Blog</a>
    <div class="navbar-dropdown">
      <button class="navbar-dropdown-toggle">Dropdown</button>
      <ul class="navbar-dropdown-menu">
        <li><a href="/blogdetail">Blog detail</a></li>
        <li><a href="/link2">Link 2</a></li>
        <li><a href="/link3">Link 3</a></li>
      </ul>
    </div>
    <form action="/search-results" method="get" class="navbar-search">
      <input type="text" name="query" placeholder="Zoeken naar..." />
    </form>

    <a href="#" class="navbar-button">Contact</a>
  </div>
</nav>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    const dropdownToggle = document.querySelector('.navbar-dropdown-toggle');
    const dropdownMenu = document.querySelector('.navbar-dropdown-menu');
    const menuMobile = document.querySelector('.navbar-menu-mobile');
    const navbarMenu = document.querySelector('.navbar-menu');

    dropdownToggle.addEventListener('click', function () {
      dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
    });

    window.addEventListener('click', function (e) {
      if (!dropdownToggle.contains(e.target) && !dropdownMenu.contains(e.target)) {
        dropdownMenu.style.display = 'none';
      }
    });

    menuMobile.addEventListener('click', function () {
      menuMobile.classList.toggle('open');
      navbarMenu.classList.toggle('open');
    });
  });
</script>
